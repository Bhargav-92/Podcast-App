//
//  PodcastAppUIApp.swift
//  PodcastAppUI
//
//  Created by Shameem Reza on 22/3/22.
//

import SwiftUI

@main
struct PodcastAppUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
