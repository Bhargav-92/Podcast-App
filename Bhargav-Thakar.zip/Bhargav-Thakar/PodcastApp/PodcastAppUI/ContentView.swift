//
//  ContentView.swift
//  PodcastAppUI
//
//  Created by Shameem Reza on 22/3/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
